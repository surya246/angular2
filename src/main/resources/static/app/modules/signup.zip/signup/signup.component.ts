import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'signup',
    templateUrl: 'signup.html',
    styleUrls:['signup.css']
})

export class SignUpComponent implements OnInit {
    constructor() { }

    ngOnInit() { }
}