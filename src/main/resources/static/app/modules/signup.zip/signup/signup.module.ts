import { NgModule } from '@angular/core';
import { HttpModule } from "@angular/http";
import { Http, Headers, Response, RequestOptions } from '@angular/http';
import { FormsModule, ReactiveFormsModule } from "@angular/forms"
import { RouterModule, Routes } from '@angular/router';

import { SignUpComponent } from './signup.component';
import { SignUpRoutingModule } from './signup.routing';
import { SignUpService } from "./signup.service";
import { CommonModule } from '@angular/common';
import { ShareModule } from './../../modules/common/share.module';

@NgModule({
    imports: [
        SignUpRoutingModule,
        FormsModule,
        ReactiveFormsModule,
        RouterModule,
        CommonModule,
        ShareModule,
    ],
    exports: [],
    declarations: [SignUpComponent],
    providers: [],
})

export class SignUpModule { }
